export const AUTH_CONFIG = {
  domain: 'mrksihna2025.auth0.com',
  clientId: 'J5DjuQdpGUyu50IH2UeDwWn7pxkUwo41',
  callbackUrl: 'http://localhost:3000/callback'
}
